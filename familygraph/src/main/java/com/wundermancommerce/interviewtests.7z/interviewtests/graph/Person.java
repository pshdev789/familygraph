package com.wundermancommerce.interviewtests.graph;

import lombok.Data;

@Data
public class Person {

	private String name;
	private String email;
	private int age;

	public Person(String name, String email, int age) {
		super();
		this.name = name;
		this.email = email;
		this.age = age;
	}

}
