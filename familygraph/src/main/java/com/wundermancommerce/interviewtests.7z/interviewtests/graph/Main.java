package com.wundermancommerce.interviewtests.graph;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		getPeople();
	}

	public static  List<Person> getPeople() {
		List<Person> people = new ArrayList<>();
		try {

			Path path = Paths.get("src/test/resources/people.csv");
			String read = Files.readAllLines(path).get(0);

			if (read != null) {
				String[] peopleArr = read.split(",");
				Person person = new Person(peopleArr[0], peopleArr[1], Integer.valueOf(peopleArr[2]));
				people.add(person);
			}

		} catch (IOException e) {
			System.err.format("IOException: %s%n", e);
		}
		return people;
	}

}
