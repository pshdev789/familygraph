package com.wundermancommerce.interviewtests.graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.wundermancommerce.interviewtests.util.Relationship;

import lombok.Data;

@Data
public class Graph {

	private Map<Person, List<Person>> people;
	private Relationship relationShip;
	
	void addVertex(String name, String email, int age) {
		people.putIfAbsent(new Person(name, email, age), new ArrayList<>());
	}

	void removeVertex(String name, String email, int age) {
		Person v = new Person(name, email, age);
		people.values().stream().forEach(e -> e.remove(v));
		people.remove(new Person(name, email, age));
	}

}
