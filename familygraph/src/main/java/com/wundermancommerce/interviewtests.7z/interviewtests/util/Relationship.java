package com.wundermancommerce.interviewtests.util;
   public enum Relationship {
        
	   FAMILY,
        FRIEND
    }