package com.wundermancommerce.interviewtests.graph;

import com.wundermancommerce.interviewtests.util.Relationship;

public class Relation {

	private Relationship relationShip;
    private Person person;
}
